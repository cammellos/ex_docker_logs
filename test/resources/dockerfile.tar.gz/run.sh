 #!/bin/bash

 COUNTER=0
 while true; do
     echo $COUNTER
     let COUNTER=COUNTER+1
 done
